def secret_function():
    """
    This function print my username
    """
    print("My username is noamoa and I read the submission response.")
